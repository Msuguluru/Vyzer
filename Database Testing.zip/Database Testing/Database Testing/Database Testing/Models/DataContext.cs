﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Database_Testing.Models
{
    public class DataContext
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString());
        public List<ProductionSets> GetPrds()
        {
            List<ProductionSets> prdlist = new List<ProductionSets>();
           // string conn = con.ToString();
            string query = "Select * from ProductionSets";
            SqlDataAdapter da = new SqlDataAdapter(query,con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            foreach (DataRow item in dt.Rows)
            {
                ProductionSets prds = new ProductionSets();
                prds.Pid = (int)item["Pid"];
                prds.Pname = (string)item["Pname"];
                prds.CaseId = (int)item["CaseId"];
                prdlist.Add(prds);
            }
            return prdlist;
        }
    }
}