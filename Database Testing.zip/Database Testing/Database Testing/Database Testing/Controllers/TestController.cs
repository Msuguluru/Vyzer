﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Database_Testing.Models;

namespace Database_Testing.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        DataContext dc = new DataContext();
        public ActionResult Index()
        {
            List<ProductionSets> prdlist = dc.GetPrds();

            return View(prdlist);
        }
    }
}